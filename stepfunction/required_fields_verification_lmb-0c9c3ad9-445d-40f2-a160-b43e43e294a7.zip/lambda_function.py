import json

def lambda_handler(event, context):
    name = event.get('name')
    message = f"Hello {name}"
    return {
        "name": name,
        "message": message
    }

import boto3

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    bucket_name = "stepfunctiontest27"
    key = "test_data.xlsx"
    
    try:
        s3.head_object(Bucket=bucket_name, Key=key)
        return {
            'status': 'exists',
            'bucket': bucket_name,
            'key': key
        }
    except s3.exceptions.ClientError as e:
        return {
            'status': 'not_found',
            'error': str(e)
        }

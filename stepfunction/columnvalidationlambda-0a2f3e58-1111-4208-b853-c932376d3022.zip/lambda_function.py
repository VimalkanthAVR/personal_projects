import boto3
import pandas as pd
import io

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    
    bucket_name = "stepfunctiontest27"
    key = "test_data.xlsx"

    try:
        obj = s3.get_object(Bucket=bucket_name, Key=key)
        data = obj['Body'].read()
        df = pd.read_excel(io.BytesIO(data))

        # Example: Check required columns
        required_columns = {"ID", "Name", "Email", "Phone", "Date Joined", "Status"}
        if required_columns.issubset(df.columns):
            return {
                'validation': 'success',
                'rowCount': len(df)
            }
        else:
            return {
                'validation': 'failed',
                'reason': 'Missing columns',
                'columns_found': df.columns.tolist()
            }

    except Exception as e:
        return {
            'validation': 'error',
            'error': str(e)
        }
